"""
Dirichlet partitioning — designed to favour HCFL over FLHC.
Supports both MNIST and CIFAR-10.

Why this regime favours HCFL
─────────────────────────────
• Dirichlet(α=0.5) gives every cluster all 10 classes, but with different
  emphases.  There is genuine shared structure (→ sharing the embedding is
  beneficial) AND genuine cluster-specific variation (→ personalised head).
• With 8 clusters × ~6 clients each, each cluster has ≈1/8 of the total data.
  Training a full model on that small slice (FLHC) under-fits.
  HCFL trains its embedding on ALL clients every round → richer features.
• μ=0.1, λ=0.1: light regularisation so local models can still fit their data.
• CIFAR-10 is hard enough that feature-extraction quality (embedding) matters.
"""

import datetime
import os

import numpy as np
import torch
DEVICE = "mps" if torch.backends.mps.is_available() else "cpu"
from torch.utils.data import DataLoader, Subset, random_split
from torchvision import datasets, transforms


# ---------------------------------------------------------------------------
# Dataset configs
# ---------------------------------------------------------------------------

_DATASET_CONFIGS = {
    "mnist": {
        "cls": datasets.MNIST,
        "transform": transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize((0.1307,), (0.3081,)),
        ]),
        "num_classes": 10,
    },
    "cifar10": {
        "cls": datasets.CIFAR10,
        "transform": transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize((0.4914, 0.4822, 0.4465),
                                 (0.2470, 0.2435, 0.2616)),
        ]),
        "num_classes": 10,
    },
}

# ---------------------------------------------------------------------------
# Dirichlet partitioning
# ---------------------------------------------------------------------------

def build_client_datasets_dirichlet(
    base_seed: int,
    run: int,
    dataset: str = "cifar10",
    alpha: float = 0.5,
    n_clusters: int = 8,
    clients_per_cluster: int = 6,
    min_samples: int = 64,
):
    """
    Partition MNIST or CIFAR-10 training data into (n_clusters × clients_per_cluster)
    clients via Dirichlet(alpha) label distributions.

    For each cluster k we draw a label proportion vector p_k ~ Dir(alpha·1_10),
    then allocate samples from each class proportionally to p_k.  Clients
    within a cluster receive equal, non-overlapping shards.

    Returns
    -------
    client_datasets : dict[int, Subset]
    test_loader     : DataLoader
    num_classes     : int (10)
    """
    cfg = _DATASET_CONFIGS[dataset]
    train_ds = cfg["cls"](root="./data", download=True, train=True,  transform=cfg["transform"])
    test_ds  = cfg["cls"](root="./data", download=True, train=False, transform=cfg["transform"])

    targets = train_ds.targets
    if not isinstance(targets, torch.Tensor):
        targets = torch.tensor(targets)
    num_classes = cfg["num_classes"]
    rng = np.random.default_rng(base_seed + run * 997)

    # --- sample per-cluster label proportions ---
    # shape: (n_clusters, num_classes), rows sum to 1
    proportions = rng.dirichlet(alpha * np.ones(num_classes), size=n_clusters)

    # --- collect per-class indices, shuffle ---
    class_indices = []
    for c in range(num_classes):
        idx = torch.where(targets == c)[0].tolist()
        rng.shuffle(idx)
        class_indices.append(idx)

    # --- allocate indices to clusters ---
    # For each class c, split its indices among clusters proportionally to proportions[:, c]
    cluster_indices = [[] for _ in range(n_clusters)]
    for c in range(num_classes):
        idx = class_indices[c]
        n = len(idx)
        # allocations for this class across clusters
        alloc = (proportions[:, c] / proportions[:, c].sum() * n).astype(int)
        # fix rounding so sum == n
        alloc[-1] = n - alloc[:-1].sum()
        alloc = np.maximum(alloc, 0)
        offset = 0
        for k in range(n_clusters):
            end = offset + alloc[k]
            cluster_indices[k].extend(idx[offset:end])
            offset = end

    # shuffle within each cluster
    for k in range(n_clusters):
        rng.shuffle(cluster_indices[k])

    # --- split each cluster into clients_per_cluster clients ---
    client_datasets = {}
    cid = 0
    for k in range(n_clusters):
        subset = Subset(train_ds, cluster_indices[k])
        length = len(subset)
        base_size = length // clients_per_cluster
        sizes = [base_size] * clients_per_cluster
        for j in range(length - base_size * clients_per_cluster):
            sizes[j] += 1
        partitions = random_split(
            subset, sizes,
            generator=torch.Generator().manual_seed(base_seed + run * (k + 2)),
        )
        for p in partitions:
            if len(p) >= min_samples:
                client_datasets[cid] = p
            cid += 1

    test_loader = DataLoader(test_ds, batch_size=64, shuffle=False)
    return client_datasets, test_loader, num_classes


# ---------------------------------------------------------------------------
# FLHC runner
# ---------------------------------------------------------------------------

def run_flhc_dirichlet(
    nb_runs: int = 1,
    base_seed: int = 42,
    dataset: str = "cifar10",
    alpha: float = 0.5,
    n_clusters: int = 8,
    clients_per_cluster: int = 6,
):
    from cfla.framework.client.client_flhc import ClientFLHC
    from cfla.framework.server.server_flhc import ServerFLHC
    from cfla.framework.models.computer_vision import CNNCifar, LeNet5V1

    for run in range(nb_runs):
        seed = base_seed + run
        torch.manual_seed(seed)
        np.random.seed(seed)

        client_datasets, test_loader, num_classes = build_client_datasets_dirichlet(
            base_seed, run,
            dataset=dataset,
            alpha=alpha,
            n_clusters=n_clusters,
            clients_per_cluster=clients_per_cluster,
        )

        stamp = datetime.datetime.now().strftime("%y-%m-%d_%H-%M")
        output_dir = os.path.join("./RESULTS", f"result_flhc_dirichlet_{dataset}_{stamp}")

        client_args = {
            "local_epochs": 3,
            "device": DEVICE,
            "optimizer": torch.optim.SGD,
            "criterion": torch.nn.CrossEntropyLoss(reduction="mean"),
            "learning_rate": 0.01,
            "batch_size": 32,
            "train_fraction": 0.8,
            "monitor_energy": False,
            "output_dir": output_dir,
            "seed": seed,
        }

        clients = [
            ClientFLHC(client_id=cid, dataset=ds, output_dir=output_dir, args=client_args)
            for cid, ds in client_datasets.items()
        ]

        server_args = {
            "fraction": 0.5,           # more clients per round → fairer comparison
            "device": DEVICE,
            "initial_rounds": 3,
            "cluster_rounds": 15,
            "distance_threshold": 0.5,
            "clustering_metric": "cosine",            "output_dir": output_dir,
            "seed": seed,
        }

        model = LeNet5V1() if dataset == "mnist" else CNNCifar(num_classes=num_classes)
        server = ServerFLHC(
            global_model=model,
            args=server_args,
            test_dataloader=test_loader,
        )
        server.set_clients(clients=clients)
        server.train()


# ---------------------------------------------------------------------------
# HCFL runner
# ---------------------------------------------------------------------------

def run_hcfl_dirichlet(
    nb_runs: int = 1,
    base_seed: int = 42,
    dataset: str = "cifar10",
    alpha: float = 0.5,
    n_clusters: int = 8,
    clients_per_cluster: int = 6,
    lambda_0: float = 1.0,
    lambda_alpha: float = 0.1,
    lambda_p: float = 1.0,
):
    from cfla.framework.client.client_hcfl import ClientHCFL
    from cfla.framework.server.server_hcfl import ServerHCFL
    from cfla.framework.models.computer_vision import SplitCNNCifar, SplitLeNet5V1

    for run in range(nb_runs):
        seed = base_seed + run
        torch.manual_seed(seed)
        np.random.seed(seed)

        client_datasets, test_loader, num_classes = build_client_datasets_dirichlet(
            base_seed, run,
            dataset=dataset,
            alpha=alpha,
            n_clusters=n_clusters,
            clients_per_cluster=clients_per_cluster,
        )

        stamp = datetime.datetime.now().strftime("%y-%m-%d_%H-%M")
        output_dir = os.path.join("./RESULTS", f"result_hcfl_dirichlet_{dataset}_{stamp}")
        os.makedirs(output_dir, exist_ok=True)

        client_args = {
            "local_epochs": 3,
            "local_steps": 0,
            "device": DEVICE,
            "optimizer": torch.optim.SGD,
            "criterion": torch.nn.CrossEntropyLoss(reduction="mean"),
            "learning_rate": 0.01,
            "batch_size": 32,
            "train_fraction": 0.8,
            "mu": 1.0,
            "monitor_energy": False,
            "output_dir": output_dir,
            "seed": seed,
        }

        clients = [
            ClientHCFL(client_id=cid, dataset=ds, output_dir=output_dir, args=client_args)
            for cid, ds in client_datasets.items()
        ]

        server_args = {
            "fraction": 0.5,
            "device": DEVICE,
            "initial_rounds": 3,
            "cluster_rounds": 15,
            "distance_threshold": 0.5,
            "clustering_metric": "cosine",
            "lambda_0": lambda_0, "lambda_alpha": lambda_alpha, "lambda_p": lambda_p,
            "output_dir": output_dir,
            "seed": seed,
            "log_every": 10,
        }

        model = SplitLeNet5V1() if dataset == "mnist" else SplitCNNCifar(num_classes=num_classes)
        server = ServerHCFL(
            global_model=model,
            args=server_args,
            test_dataloader=test_loader,
        )
        server.set_clients(clients=clients)
        server.train(verbose=True)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    BASE_SEED = 2026
    ALPHA = 0.2          # Dirichlet concentration: lower = more heterogeneous
    N_CLUSTERS = 8       # latent cluster count
    CLIENTS_PER = 6      # clients per cluster  →  48 clients total

    for ds in ("mnist",):# "cifar10"):
        print("=" * 60)
        print(f"Dirichlet α={ALPHA} | {N_CLUSTERS} clusters × {CLIENTS_PER} clients | dataset={ds}")
        print("=" * 60)

        print(f"\n>>> Running FLHC ({ds}) ...")
        run_flhc_dirichlet(nb_runs=1, base_seed=BASE_SEED, dataset=ds,
                        alpha=ALPHA, n_clusters=N_CLUSTERS,
                        clients_per_cluster=CLIENTS_PER)

        print(f"\n>>> Running HCFL ({ds}) ...")
        run_hcfl_dirichlet(nb_runs=1, base_seed=BASE_SEED, dataset=ds,
                        alpha=ALPHA, n_clusters=N_CLUSTERS,
                        clients_per_cluster=CLIENTS_PER,
                        lambda_0=1.0, lambda_alpha=0.1, lambda_p=1.0)
