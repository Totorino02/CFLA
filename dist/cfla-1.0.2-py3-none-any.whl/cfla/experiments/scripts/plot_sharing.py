"""
Visualisation des métriques de partage inter-clusters pour HCFL.

Usage:
    # Après une ablation :
    python -m experiments.scripts.plot_sharing --dir ./RESULTS/ablation_sharing_mnist_XX-XX-XX_XX-XX

    # Sur un seul run (juste divergence + accuracy par cluster) :
    python -m experiments.scripts.plot_sharing --dir ./RESULTS/result_hcfl_mnist_XX-XX-XX_XX-XX --single
"""

import argparse
import os

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def load_server(path: str) -> pd.DataFrame:
    return pd.read_csv(os.path.join(path, "server_metrics.csv"))

def load_cluster(path: str) -> pd.DataFrame:
    return pd.read_csv(os.path.join(path, "cluster_metrics.csv"))

def load_client(path: str, client_id: int) -> pd.DataFrame:
    return pd.read_csv(os.path.join(path, f"client_{client_id}", "metrics.csv"))


# ---------------------------------------------------------------------------
# Plot 1 — Divergence Ω_k ↔ Φ par cluster au fil du temps
# (Test 3 : les clusters doivent diverger progressivement = spécialisation)
# ---------------------------------------------------------------------------

def plot_omega_phi_divergence(result_dir: str, save: bool = True):
    df = load_cluster(result_dir)
    clusters = sorted(df["cluster"].unique())

    fig, ax = plt.subplots(figsize=(8, 4))
    for k in clusters:
        sub = df[df["cluster"] == k].sort_values("round")
        n = sub["n_clients"].iloc[0]
        ax.plot(sub["round"], sub["omega_phi_dist"], label=f"Cluster {k} (n={n})")

    # λ(t) sur axe secondaire
    if "lambda" in df.columns:
        ax2 = ax.twinx()
        sub0 = df[df["cluster"] == clusters[0]].sort_values("round")
        ax2.plot(sub0["round"], sub0["lambda"], "k--", alpha=0.4, label="λ(t)")
        ax2.set_ylabel("λ(t)", color="grey")
        ax2.tick_params(axis="y", labelcolor="grey")

    ax.set_xlabel("Round")
    ax.set_ylabel("‖Ω_k − Φ‖₂")
    ax.set_title("Divergence Ω_k ↔ Φ (spécialisation des clusters)")
    ax.legend(loc="upper left")
    plt.tight_layout()
    if save:
        out = os.path.join(result_dir, "omega_phi_divergence.png")
        plt.savefig(out, dpi=150)
        print(f"Saved: {out}")
    plt.show()


# ---------------------------------------------------------------------------
# Plot 2 — Accuracy par cluster au fil du temps
# ---------------------------------------------------------------------------

def plot_cluster_accuracy(result_dir: str, save: bool = True):
    df = load_cluster(result_dir)
    clusters = sorted(df["cluster"].unique())

    fig, ax = plt.subplots(figsize=(8, 4))
    for k in clusters:
        sub = df[df["cluster"] == k].sort_values("round")
        n = sub["n_clients"].iloc[0]
        ax.plot(sub["round"], sub["mean_acc"], label=f"Cluster {k} (n={n})")

    ax.set_xlabel("Round")
    ax.set_ylabel("Accuracy moyenne")
    ax.set_title("Accuracy par cluster")
    ax.legend()
    plt.tight_layout()
    if save:
        out = os.path.join(result_dir, "cluster_accuracy.png")
        plt.savefig(out, dpi=150)
        print(f"Saved: {out}")
    plt.show()


# ---------------------------------------------------------------------------
# Plot 3 — Ablation : accuracy globale des 3 variantes
# (Test 1 : share > noShare, surtout pour les petits clusters)
# ---------------------------------------------------------------------------

def plot_ablation_accuracy(ablation_dir: str, save: bool = True):
    variants = [d for d in os.listdir(ablation_dir)
                if os.path.isdir(os.path.join(ablation_dir, d))
                and os.path.exists(os.path.join(ablation_dir, d, "server_metrics.csv"))]

    fig, ax = plt.subplots(figsize=(8, 4))
    for v in sorted(variants):
        df = load_server(os.path.join(ablation_dir, v))
        ax.plot(df["round"], df["mean_acc"], label=v)
        ax.fill_between(
            df["round"],
            df["mean_acc"] - df["std_acc"],
            df["mean_acc"] + df["std_acc"],
            alpha=0.15,
        )

    ax.set_xlabel("Round")
    ax.set_ylabel("Accuracy moyenne (tous clients)")
    ax.set_title("Ablation : noShare vs share vs fullShare")
    ax.legend()
    plt.tight_layout()
    if save:
        out = os.path.join(ablation_dir, "ablation_accuracy.png")
        plt.savefig(out, dpi=150)
        print(f"Saved: {out}")
    plt.show()


# ---------------------------------------------------------------------------
# Plot 4 — Benefit ratio par cluster (Test 2)
# BR(k) = (acc_share - acc_noShare) / (1 / |C_k|)
# Doit être positivement corrélé avec 1/|C_k|
# ---------------------------------------------------------------------------

def plot_benefit_ratio(ablation_dir: str, save: bool = True):
    path_share   = os.path.join(ablation_dir, "share",   "cluster_metrics.csv")
    path_noshare = os.path.join(ablation_dir, "noShare", "cluster_metrics.csv")
    if not os.path.exists(path_share) or not os.path.exists(path_noshare):
        print("benefit_ratio: cluster_metrics.csv manquant pour share ou noShare")
        return

    df_s  = pd.read_csv(path_share).groupby("cluster").agg(
        mean_acc=("mean_acc", "mean"), n_clients=("n_clients", "first")
    ).reset_index()
    df_ns = pd.read_csv(path_noshare).groupby("cluster").agg(
        mean_acc=("mean_acc", "mean"), n_clients=("n_clients", "first")
    ).reset_index()

    merged = df_s.merge(df_ns, on="cluster", suffixes=("_share", "_noshare"))
    merged["br"] = (merged["mean_acc_share"] - merged["mean_acc_noshare"]) / (1.0 / merged["n_clients_share"])
    merged["inv_size"] = 1.0 / merged["n_clients_share"]

    fig, axes = plt.subplots(1, 2, figsize=(10, 4))

    # Barchart benefit ratio par cluster
    axes[0].bar(merged["cluster"].astype(str), merged["br"])
    axes[0].axhline(0, color="red", linestyle="--", linewidth=0.8)
    axes[0].set_xlabel("Cluster")
    axes[0].set_ylabel("Benefit ratio")
    axes[0].set_title("Benefit ratio par cluster")

    # Scatter BR vs 1/|C_k|
    axes[1].scatter(merged["inv_size"], merged["br"], s=80)
    for _, row in merged.iterrows():
        axes[1].annotate(f"C{int(row['cluster'])} (n={int(row['n_clients_share'])})",
                         (row["inv_size"], row["br"]), textcoords="offset points", xytext=(5, 3), fontsize=8)
    axes[1].axhline(0, color="red", linestyle="--", linewidth=0.8)
    axes[1].set_xlabel("1 / |C_k|  (petits clusters à droite)")
    axes[1].set_ylabel("Benefit ratio")
    axes[1].set_title("BR corrélé avec taille inverse ?")

    corr = np.corrcoef(merged["inv_size"], merged["br"])[0, 1]
    axes[1].set_title(f"BR vs 1/|C_k|  (r={corr:.2f})")

    plt.tight_layout()
    if save:
        out = os.path.join(ablation_dir, "benefit_ratio.png")
        plt.savefig(out, dpi=150)
        print(f"Saved: {out}")
    plt.show()


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dir", required=True, help="Dossier de résultats (ablation ou single run)")
    parser.add_argument("--single", action="store_true", help="Run unique (pas d'ablation)")
    args = parser.parse_args()

    if args.single:
        plot_omega_phi_divergence(args.dir)
        plot_cluster_accuracy(args.dir)
    else:
        plot_ablation_accuracy(args.dir)
        plot_benefit_ratio(args.dir)
        # Divergence pour chaque variante
        for variant in ("noShare", "share", "fullShare"):
            vdir = os.path.join(args.dir, variant)
            if os.path.exists(os.path.join(vdir, "cluster_metrics.csv")):
                print(f"\n--- Divergence : {variant} ---")
                plot_omega_phi_divergence(vdir, save=True)


if __name__ == "__main__":
    main()
