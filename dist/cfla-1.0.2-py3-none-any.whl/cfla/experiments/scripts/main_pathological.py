"""
Pathological non-IID partitioning (McMahan et al., 2017).

Each client receives data from exactly `n_classes_per_client` classes,
drawn without pre-imposed cluster structure. The algorithms (HCFL, FLHC,
LCFed) must discover the natural groupings on their own.

Protocol
────────
1. Sort all training samples by class label.
2. Divide into (n_classes_per_client × num_clients) equal shards.
3. Assign n_classes_per_client shards to each client (without replacement).

With n=2: strict, clients see only 2 classes → strong heterogeneity.
With n=3: moderate, clients see 3 classes → natural clusters emerge.
With n=4: softer, clients see 4 classes → less heterogeneous.

No cluster labels are used at partition time.
"""

import datetime
import os

import numpy as np
import torch

DEVICE = "mps" if torch.backends.mps.is_available() else "cpu"
from torch.utils.data import DataLoader, Subset
from torchvision import datasets, transforms


# ---------------------------------------------------------------------------
# Dataset configs
# ---------------------------------------------------------------------------

_DATASET_CONFIGS = {
    "mnist": {
        "cls": datasets.MNIST,
        "transform": transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize((0.1307,), (0.3081,)),
        ]),
        "num_classes": 10,
    },
    "cifar10": {
        "cls": datasets.CIFAR10,
        "transform": transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize((0.4914, 0.4822, 0.4465),
                                 (0.2470, 0.2435, 0.2616)),
        ]),
        "num_classes": 10,
    },
}


# ---------------------------------------------------------------------------
# Partitioning
# ---------------------------------------------------------------------------

def build_client_datasets_pathological(
    base_seed: int,
    run: int,
    dataset: str = "mnist",
    num_clients: int = 50,
    n_classes_per_client: int = 2,
):
    """
    Classical pathological non-IID partitioning.

    Data is sorted by label, split into (n_classes_per_client × num_clients)
    equal shards, then shards are randomly assigned so each client gets exactly
    n_classes_per_client shards. No cluster structure is imposed.

    Parameters
    ----------
    num_clients          : total number of clients
    n_classes_per_client : number of classes each client sees (n=2, 3, or 4)

    Returns
    -------
    client_datasets : dict[int, Subset]
    test_loader     : DataLoader
    num_classes     : int
    """
    cfg = _DATASET_CONFIGS[dataset]
    train_ds = cfg["cls"](root="./data", download=True, train=True, transform=cfg["transform"])
    test_ds  = cfg["cls"](root="./data", download=True, train=False, transform=cfg["transform"])

    targets = train_ds.targets
    if not isinstance(targets, torch.Tensor):
        targets = torch.tensor(targets)

    rng = np.random.default_rng(base_seed + run * 997)

    # Sort all indices by class label
    sorted_indices = torch.argsort(targets).tolist()

    # Split into (n_classes_per_client × num_clients) shards
    total_shards = n_classes_per_client * num_clients
    shard_size = len(sorted_indices) // total_shards
    # Drop remainder to keep all shards equal-sized
    sorted_indices = sorted_indices[:shard_size * total_shards]
    shards = [sorted_indices[i * shard_size:(i + 1) * shard_size]
              for i in range(total_shards)]

    # Randomly assign n_classes_per_client shards to each client
    shard_order = rng.permutation(total_shards).tolist()
    client_datasets = {}
    for cid in range(num_clients):
        assigned = shard_order[cid * n_classes_per_client:(cid + 1) * n_classes_per_client]
        indices = []
        for s in assigned:
            indices.extend(shards[s])
        client_datasets[cid] = Subset(train_ds, indices)

    test_loader = DataLoader(test_ds, batch_size=64, shuffle=False)
    return client_datasets, test_loader, cfg["num_classes"]


# ---------------------------------------------------------------------------
# FLHC runner
# ---------------------------------------------------------------------------

def run_flhc_pathological(
    nb_runs: int = 1,
    base_seed: int = 2026,
    dataset: str = "mnist",
    num_clients: int = 50,
    nb_rounds: int = 50,
    n_classes_per_client: int = 2,
):
    from cfla.framework.client.client_flhc import ClientFLHC
    from cfla.framework.server.server_flhc import ServerFLHC
    from cfla.framework.models.computer_vision import LeNet5V1, CNNCifar

    for run in range(nb_runs):
        seed = base_seed + run
        torch.manual_seed(seed)
        np.random.seed(seed)

        client_datasets, test_loader, num_classes = build_client_datasets_pathological(
            base_seed, run,
            dataset=dataset,
            num_clients=num_clients,
            n_classes_per_client=n_classes_per_client,
        )

        stamp = datetime.datetime.now().strftime("%y-%m-%d_%H-%M")
        tag = f"pathological_n{n_classes_per_client}"
        output_dir = os.path.join("./RESULTS", f"result_flhc_{tag}_{dataset}_{stamp}")
        os.makedirs(output_dir, exist_ok=True)

        client_args = {
            "local_epochs": 3,
            "device": DEVICE,
            "optimizer": torch.optim.SGD,
            "criterion": torch.nn.CrossEntropyLoss(reduction="mean"),
            "learning_rate": 0.01,
            "batch_size": 32,
            "train_fraction": 0.2,
            "monitor_energy": False,
            "output_dir": output_dir,
            "seed": seed,
        }

        clients = [
            ClientFLHC(client_id=cid, dataset=ds, output_dir=output_dir, args=client_args)
            for cid, ds in client_datasets.items()
            if len(ds) > 64
        ]

        server_args = {
            "fraction": 0.2,
            "device": DEVICE,
            "initial_rounds": 3,
            "cluster_rounds": nb_rounds,
            "distance_threshold": 0.5,
            "clustering_metric": "cosine",
            "output_dir": output_dir,
            "seed": seed,
        }

        model = LeNet5V1() if dataset == "mnist" else CNNCifar(num_classes=num_classes)
        server = ServerFLHC(
            global_model=model,
            args=server_args,
            test_dataloader=test_loader,
        )
        server.set_clients(clients=clients)
        server.train()


# ---------------------------------------------------------------------------
# HCFL runner
# ---------------------------------------------------------------------------

def run_hcfl_pathological(
    nb_runs: int = 1,
    base_seed: int = 2026,
    dataset: str = "mnist",
    num_clients: int = 50,
    nb_rounds: int = 50,
    n_classes_per_client: int = 2,
    lambda_0: float = 1.0,
    lambda_alpha: float = 0.1,
    lambda_p: float = 1.0,
):
    from cfla.framework.client.client_hcfl import ClientHCFL
    from cfla.framework.server.server_hcfl import ServerHCFL
    from cfla.framework.models.computer_vision import SplitLeNet5V1, SplitCNNCifar

    for run in range(nb_runs):
        seed = base_seed + run
        torch.manual_seed(seed)
        np.random.seed(seed)

        client_datasets, test_loader, num_classes = build_client_datasets_pathological(
            base_seed, run,
            dataset=dataset,
            num_clients=num_clients,
            n_classes_per_client=n_classes_per_client,
        )

        stamp = datetime.datetime.now().strftime("%y-%m-%d_%H-%M")
        tag = f"pathological_n{n_classes_per_client}"
        output_dir = os.path.join("./RESULTS", f"result_hcfl_{tag}_{dataset}_{stamp}")
        os.makedirs(output_dir, exist_ok=True)

        client_args = {
            "local_epochs": 3,
            "local_steps": 0,
            "device": DEVICE,
            "optimizer": torch.optim.SGD,
            "criterion": torch.nn.CrossEntropyLoss(reduction="mean"),
            "learning_rate": 0.01,
            "batch_size": 32,
            "train_fraction": 0.2,
            "mu": 1.0,
            "monitor_energy": False,
            "output_dir": output_dir,
            "seed": seed,
        }

        clients = [
            ClientHCFL(client_id=cid, dataset=ds, output_dir=output_dir, args=client_args)
            for cid, ds in client_datasets.items()
            if len(ds) > 64
        ]

        server_args = {
            "fraction": 0.2,
            "device": DEVICE,
            "initial_rounds": 3,
            "cluster_rounds": nb_rounds,
            "distance_threshold": 0.5,
            "clustering_metric": "cosine",
            "lambda_0": lambda_0, "lambda_alpha": lambda_alpha, "lambda_p": lambda_p,
            "output_dir": output_dir,
            "seed": seed,
            "log_every": 10,
        }

        model = SplitLeNet5V1() if dataset == "mnist" else SplitCNNCifar(num_classes=num_classes)
        server = ServerHCFL(
            global_model=model,
            args=server_args,
            test_dataloader=test_loader,
        )
        server.set_clients(clients=clients)
        server.train(verbose=True)


# ---------------------------------------------------------------------------
# LCFed runner
# ---------------------------------------------------------------------------

def run_lcfed_pathological(
    nb_runs: int = 1,
    base_seed: int = 2026,
    dataset: str = "mnist",
    num_clients: int = 50,
    n_classes_per_client: int = 2,
    nb_rounds: int = 50,
    num_clusters: int = 3,
    mu: float = 1.0,
    lam: float = 2.0,
):
    from cfla.framework.client.client_lcfed import ClientLCFed
    from cfla.framework.server.serveur_lcfed import ServerLCFed
    from cfla.framework.models.computer_vision import SplitLeNet5V1, SplitCNNCifar

    for run in range(nb_runs):
        seed = base_seed + run
        torch.manual_seed(seed)
        np.random.seed(seed)

        client_datasets, test_loader, num_classes = build_client_datasets_pathological(
            base_seed, run,
            dataset=dataset,
            num_clients=num_clients,
            n_classes_per_client=n_classes_per_client,
        )

        stamp = datetime.datetime.now().strftime("%y-%m-%d_%H-%M")
        tag = f"pathological_n{n_classes_per_client}"
        output_dir = os.path.join("./RESULTS", f"result_lcfed_{tag}_{dataset}_{stamp}")
        os.makedirs(output_dir, exist_ok=True)

        client_args = {
            "local_epochs": 3,
            "local_steps": 0,
            "device": DEVICE,
            "optimizer": torch.optim.SGD,
            "criterion": torch.nn.CrossEntropyLoss(reduction="mean"),
            "learning_rate": 0.01,
            "batch_size": 32,
            "train_fraction": 0.2,
            "mu": mu,
            "lambda": lam,
            "monitor_energy": False,
            "output_dir": output_dir,
            "seed": seed,
        }

        clients = [
            ClientLCFed(client_id=cid, dataset=ds, output_dir=output_dir, args=client_args)
            for cid, ds in client_datasets.items()
            if len(ds) > 64
        ]

        server_args = {
            "fraction": 0.2,
            "device": DEVICE,
            "rounds": nb_rounds,
            "num_clusters": num_clusters,
            "low_rank_dim": 50,
            "pca_sample_clients": 20,
            "output_dir": output_dir,
            "seed": seed,
            "log_every": 10,
        }

        model = SplitLeNet5V1() if dataset == "mnist" else SplitCNNCifar(num_classes=num_classes)
        server = ServerLCFed(
            global_model=model,
            args=server_args,
            test_dataloader=test_loader,
        )
        server.set_clients(clients=clients)
        server.train(verbose=True)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    BASE_SEED = 2026
    DATASET = "mnist"
    NB_RUNS = 1
    NUM_CLIENTS = 50
    NB_ROUNDS = 50
    # LCFed requires a fixed K — use a reasonable value (e.g. 5 for n=2, 3 for n=3/4)
    LCFED_K = {2: 5, 3: 3, 4: 3}

    for n in (3, 4):
        print("=" * 60)
        print(f"Pathological non-IID | n={n} classes/client | {NUM_CLIENTS} clients | {DATASET}")
        print("=" * 60)


        print(f"\n>>> HCFL ...")
        run_hcfl_pathological(nb_runs=NB_RUNS, base_seed=BASE_SEED,
                            dataset=DATASET, num_clients=NUM_CLIENTS,
                            n_classes_per_client=n,
                            nb_rounds=NB_ROUNDS)

        """print(f"\n>>> FLHC ...")
        run_flhc_pathological(nb_runs=NB_RUNS, base_seed=BASE_SEED,
                            dataset=DATASET, num_clients=NUM_CLIENTS,
                            n_classes_per_client=n,
                            nb_rounds=NB_ROUNDS)


        print(f"\n>>> LCFed (K={LCFED_K[n]}) ...")
        run_lcfed_pathological(nb_runs=NB_RUNS, base_seed=BASE_SEED,
                            dataset=DATASET, num_clients=NUM_CLIENTS,
                            n_classes_per_client=n,
                            num_clusters=LCFED_K[n],
                            nb_rounds=NB_ROUNDS)"""
