"""
Ablation study for HCFL — two independent axes:

  Axis 1 — Clustering signal (without knowledge transfer, lambda_0=0):
    - HCFL-embed-noShare : cluster on embedding updates  (our contribution)
    - HCFL-full-noShare  : cluster on full model updates  (≈ FL+HC)

  Axis 2 — Knowledge transfer (fixing clustering_signal="embed"):
    - HCFL-embed-noShare : lambda_0 = 0  (no inter-cluster sharing)
    - HCFL-embed-Share   : lambda_0 = 1  (full HCFL)

Supported datasets:
  mnist         — label skew, 3 class groups
  cifar10       — label skew, 3 class groups
  cifar10-rot   — concept shift, 3 rotation groups (0°/90°/180°), all 10 classes

Run with:
    python -m experiments.scripts.ablation --dataset cifar10-rot --nb_rounds 150
"""

import argparse
import datetime
import os

import numpy as np
import torch

from cfla.experiments.scripts.run_all_mnist import (
    build_client_datasets,
    build_client_datasets_rotated_cifar10,
)
from cfla.framework.client.client_hcfl import ClientHCFL
from cfla.framework.models.computer_vision import SplitCNNCifar, SplitLeNet5V1
from cfla.framework.server.server_hcfl import ServerHCFL

DEVICE = "mps" if torch.backends.mps.is_available() else "cpu"

# (variant_name, clustering_signal, lambda_0)
ABLATION_VARIANTS = [
    ("embed-noShare", "embed", 0.0),
    ("embed-Share",   "embed", 1.0),
    ("full-noShare",  "full",  0.0),
    ("full-Share",    "full",  1.0),
]


def _get_model(dataset: str, num_classes: int):
    if dataset == "mnist":
        return SplitLeNet5V1()
    return SplitCNNCifar(num_classes=num_classes)


def _load_data(dataset: str, base_seed: int, run: int, noise_ratio: float):
    if dataset == "cifar10-rot":
        return build_client_datasets_rotated_cifar10(base_seed, run)
    return build_client_datasets(base_seed, run, dataset, noise_ratio=noise_ratio)


def run_ablation(
    dataset: str = "cifar10-rot",
    nb_rounds: int = 150,
    nb_runs: int = 1,
    base_seed: int = 42,
    noise_ratio: float = 0.0,
):
    stamp = datetime.datetime.now().strftime("%y-%m-%d_%H-%M")

    for variant_name, clustering_signal, lambda_0 in ABLATION_VARIANTS:
        print(f"\n{'='*60}")
        print(f"Ablation variant: HCFL-{variant_name}  (dataset={dataset})")
        print(f"  clustering_signal={clustering_signal!r}  lambda_0={lambda_0}")
        print(f"{'='*60}")

        for run in range(nb_runs):
            seed = base_seed + run
            torch.manual_seed(seed)
            np.random.seed(seed)

            client_datasets, test_loader, num_classes = _load_data(
                dataset, base_seed, run, noise_ratio
            )

            output_dir = os.path.join(
                "./RESULTS", f"result_{variant_name}_{dataset}_{stamp}_run{run}"
            )
            os.makedirs(output_dir, exist_ok=True)

            client_args = {
                "local_epochs": 3,
                "local_steps": 0,
                "device": DEVICE,
                "learning_rate": 0.01,
                "batch_size": 32,
                "train_fraction": 0.2,
                "mu": 1.0,
                "monitor_energy": False,
                "output_dir": output_dir,
                "seed": seed,
            }

            clients = [
                ClientHCFL(client_id=cid, dataset=ds, output_dir=output_dir, args=client_args)
                for cid, ds in client_datasets.items()
                if len(ds) > 64
            ]

            server_args = {
                "fraction": 0.2,
                "device": DEVICE,
                "initial_rounds": 3,
                "cluster_rounds": nb_rounds,
                "distance_threshold": 0.5,
                "clustering_metric": "cosine",
                "clustering_signal": clustering_signal,
                "lambda_0": lambda_0,
                "lambda_alpha": 0.1,
                "lambda_p": 1.0,
                "output_dir": output_dir,
                "seed": seed,
                "log_every": 10,
            }

            server = ServerHCFL(
                global_model=_get_model(dataset, num_classes),
                args=server_args,
                test_dataloader=test_loader,
            )
            server.set_clients(clients=clients)
            server.train(verbose=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--dataset", default="cifar10-rot", choices=["mnist", "cifar10", "cifar10-rot"]
    )
    parser.add_argument("--nb_rounds", type=int, default=150)
    parser.add_argument("--nb_runs", type=int, default=1)
    parser.add_argument("--base_seed", type=int, default=42)
    parser.add_argument("--noise_ratio", type=float, default=0.0)
    args = parser.parse_args()

    run_ablation(
        dataset=args.dataset,
        nb_rounds=args.nb_rounds,
        nb_runs=args.nb_runs,
        base_seed=args.base_seed,
        noise_ratio=args.noise_ratio,
    )
