"""
Ablation study: inter-cluster sharing in HCFL.

Three variants are run on the same data partition:
  - noShare  : lambda_0 = 0  (clusters fully isolated)
  - share    : lambda_0 = 1, lambda_alpha = 0.1, lambda_p = 1  (scheduled sharing)
  - fullShare: lambda_0 = 1, lambda_alpha = 0, lambda_p = 1    (constant lambda = 1)

Results land in ./RESULTS/ablation_sharing_<dataset>_<stamp>/
  <variant>/server_metrics.csv
  <variant>/cluster_metrics.csv
  <variant>/client_<id>/metrics.csv

Usage:
    python -m experiments.scripts.ablation_sharing
"""

import datetime
import os

import numpy as np
import torch

DEVICE = "mps" if torch.backends.mps.is_available() else "cpu"

# ---------------------------------------------------------------------------
# Variants
# ---------------------------------------------------------------------------

VARIANTS = {
    "noShare":   dict(lambda_0=0.0, lambda_alpha=0.0, lambda_p=1.0),
    "share":     dict(lambda_0=1.0, lambda_alpha=0.1, lambda_p=1.0),
    "fullShare": dict(lambda_0=1.0, lambda_alpha=0.0, lambda_p=1.0),
}


# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------

def run_ablation(
    dataset: str = "mnist",
    nb_runs: int = 1,
    base_seed: int = 2026,
    nb_rounds: int = 50,
    n_clients: int = 50,
    alpha: float = 0.1,
    max_samples_per_client: int = None,
    mu: float = 1.0,
):
    from cfla.framework.client.client_hcfl import ClientHCFL
    from cfla.framework.server.server_hcfl import ServerHCFL

    if dataset == "femnist":
        from cfla.datasets.femnist import build_client_datasets_femnist
        from cfla.framework.models.computer_vision import SplitLeNet5FEMNIST
        model_fn = lambda nc: SplitLeNet5FEMNIST(num_classes=nc)
        def build_fn(seed, run):
            return build_client_datasets_femnist(
                seed, run, n_clients=n_clients, alpha=alpha,
                max_samples_per_client=max_samples_per_client,
            )
    else:
        from cfla.experiments.scripts.run_all_mnist import build_client_datasets
        from cfla.framework.models.computer_vision import SplitLeNet5V1, SplitCNNCifar
        model_fn = lambda nc: SplitLeNet5V1() if dataset == "mnist" else SplitCNNCifar(num_classes=nc)
        def build_fn(seed, run):
            return build_client_datasets(seed, run, dataset)

    stamp = datetime.datetime.now().strftime("%y-%m-%d_%H-%M")
    base_dir = os.path.join("./RESULTS", f"ablation_sharing_{dataset}_{stamp}")
    os.makedirs(base_dir, exist_ok=True)

    for variant_name, lam_kwargs in VARIANTS.items():
        print(f"\n{'='*60}")
        print(f"Variant: {variant_name}  |  {lam_kwargs}")
        print(f"{'='*60}")

        for run in range(nb_runs):
            seed = base_seed + run
            torch.manual_seed(seed)
            np.random.seed(seed)

            client_datasets, test_loader, num_classes = build_fn(base_seed, run)

            output_dir = os.path.join(base_dir, variant_name)
            os.makedirs(output_dir, exist_ok=True)

            client_args = {
                "local_epochs": 3,
                "local_steps": 0,
                "device": DEVICE,
                "optimizer": torch.optim.SGD,
                "criterion": torch.nn.CrossEntropyLoss(reduction="mean"),
                "learning_rate": 0.01,
                "batch_size": 32,
                "train_fraction": 0.2,
                "mu": mu,
                "monitor_energy": False,
                "output_dir": output_dir,
                "seed": seed,
            }

            clients = [
                ClientHCFL(client_id=cid, dataset=ds, output_dir=output_dir, args=client_args)
                for cid, ds in client_datasets.items()
                if len(ds) > 64
            ]

            server_args = {
                "fraction": 0.2,
                "device": DEVICE,
                "initial_rounds": 3,
                "cluster_rounds": nb_rounds,
                "n_clusters": 5,
                "output_dir": output_dir,
                "seed": seed,
                "log_every": 10,
                **lam_kwargs,
            }

            server = ServerHCFL(
                global_model=model_fn(num_classes),
                args=server_args,
                test_dataloader=test_loader,
            )
            server.set_clients(clients=clients)
            server.train(verbose=True)

    print(f"\nDone. Results in: {base_dir}")
    return base_dir


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    run_ablation(
        dataset="femnist",
        nb_runs=1,
        base_seed=2026,
        nb_rounds=150,
        n_clients=50,
        alpha=0.1,
        mu=1.0,
        max_samples_per_client=300,
    )
