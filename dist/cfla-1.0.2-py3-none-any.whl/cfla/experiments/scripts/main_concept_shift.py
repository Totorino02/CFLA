"""
Concept-shift (label-permutation) partitioning — designed to favour HCFL over FLHC.

Why this regime favours HCFL
──────────────────────────────
• All clients receive the same visual features (balanced CIFAR-10 across all 10
  classes), but each cluster is assigned a different permutation of the 10 class
  labels.  The optimal feature extractor is therefore IDENTICAL for every cluster
  (same visual content), while the classification head must be cluster-specific.

• HCFL explicitly separates the model into a global embedding Φ (shared and
  averaged across ALL 30 clients every round) and a cluster head Ω_k.
  → Φ trains on 30 × ~800 = 24 000 CIFAR-10 samples.

• FLHC trains a full model per cluster after one-shot clustering.
  → Each cluster's feature extractor trains on only 6 × ~800 = 4 800 samples.

• The 5× data-advantage for HCFL's embedding is decisive on CIFAR-10 where
  convolutional features require sufficient data to generalise.

• HCFL's embedding-based clustering signal (∇embed) correlates with shared
  feature learning patterns, while label permutation mostly affects the head.
  This makes HCFL's clustering more robust in this regime.

Regime parameters
─────────────────
  5 clusters × 6 clients = 30 clients
  Balanced class distribution (not label-skewed)
  5 distinct label permutations, one per cluster
  train_fraction = 0.5  →  each client ≈ 800 training samples
  HCFL : μ=0.5, λ=1.0  (moderate pull toward global Φ)
"""

import datetime
import os

import numpy as np
import torch
DEVICE = "mps" if torch.backends.mps.is_available() else "cpu"
from torch.utils.data import DataLoader, Dataset, Subset, random_split
from torchvision import datasets, transforms


# ---------------------------------------------------------------------------
# Transforms
# ---------------------------------------------------------------------------

_CIFAR10_TRANSFORM = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize((0.4914, 0.4822, 0.4465),
                         (0.2470, 0.2435, 0.2616)),
])

# ---------------------------------------------------------------------------
# Label permutations — one per cluster, must be distinct
# ---------------------------------------------------------------------------
# Each permutation is a list p such that original label y is mapped to p[y].
# Chosen to maximise dissimilarity between clusters.

_PERMUTATIONS = [
    [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],   # cluster 0 – identity
    [5, 6, 7, 8, 9, 0, 1, 2, 3, 4],   # cluster 1 – rotate +5
    [9, 8, 7, 6, 5, 4, 3, 2, 1, 0],   # cluster 2 – reverse
    [2, 3, 0, 1, 6, 7, 4, 5, 9, 8],   # cluster 3 – swap pairs
    [4, 5, 6, 7, 8, 9, 0, 1, 2, 3],   # cluster 4 – rotate +4
]

N_CLUSTERS = len(_PERMUTATIONS)
CLIENTS_PER_CLUSTER = 6


# ---------------------------------------------------------------------------
# Dataset wrapper
# ---------------------------------------------------------------------------

class _LabelPermutedDataset(Dataset):
    """Wraps a dataset and remaps each label y → permutation[y]."""

    def __init__(self, base_dataset, permutation):
        self.base_dataset = base_dataset
        self.perm = permutation

    def __len__(self):
        return len(self.base_dataset)

    def __getitem__(self, idx):
        x, y = self.base_dataset[idx]
        return x, self.perm[y]


# ---------------------------------------------------------------------------
# Dataset builder
# ---------------------------------------------------------------------------

def build_client_datasets_concept_shift(
    base_seed: int,
    run: int,
    n_clusters: int = N_CLUSTERS,
    clients_per_cluster: int = CLIENTS_PER_CLUSTER,
    permutations: list = None,
):
    """
    Partition CIFAR-10 into (n_clusters × clients_per_cluster) clients.

    Each cluster receives a balanced slice of the training set (all 10 classes
    equally represented) with a cluster-specific label permutation applied.
    Within a cluster, clients receive disjoint equal-sized shards.

    Returns
    -------
    client_datasets : dict[int, Dataset]
    test_loader     : DataLoader (standard CIFAR-10 test set, unpermuted)
    num_classes     : int (10)
    """
    if permutations is None:
        permutations = _PERMUTATIONS[:n_clusters]

    train_ds = datasets.CIFAR10(root="./data", download=True, train=True,
                                transform=_CIFAR10_TRANSFORM)
    test_ds  = datasets.CIFAR10(root="./data", download=True, train=False,
                                transform=_CIFAR10_TRANSFORM)

    targets = torch.tensor(train_ds.targets)
    num_classes = 10
    rng = np.random.default_rng(base_seed + run * 997)

    # Collect per-class indices (shuffled for reproducibility)
    class_indices = []
    for c in range(num_classes):
        idx = torch.where(targets == c)[0].tolist()
        rng.shuffle(idx)
        class_indices.append(idx)

    # Each cluster receives an equal balanced share:
    # n_per_class_per_cluster = floor(n_class_samples / n_clusters)
    cluster_indices = [[] for _ in range(n_clusters)]
    for c in range(num_classes):
        idx = class_indices[c]
        per_cluster = len(idx) // n_clusters
        for k in range(n_clusters):
            cluster_indices[k].extend(idx[k * per_cluster: (k + 1) * per_cluster])

    for k in range(n_clusters):
        rng.shuffle(cluster_indices[k])

    # Split each cluster into clients_per_cluster clients, apply label permutation
    client_datasets = {}
    cid = 0
    for k in range(n_clusters):
        subset = Subset(train_ds, cluster_indices[k])
        length = len(subset)
        base_size = length // clients_per_cluster
        sizes = [base_size] * clients_per_cluster
        for j in range(length - base_size * clients_per_cluster):
            sizes[j] += 1
        partitions = random_split(
            subset, sizes,
            generator=torch.Generator().manual_seed(base_seed + run * (k + 2)),
        )
        perm = permutations[k]
        for p in partitions:
            client_datasets[cid] = _LabelPermutedDataset(p, perm)
            cid += 1

    test_loader = DataLoader(test_ds, batch_size=64, shuffle=False)
    return client_datasets, test_loader, num_classes


# ---------------------------------------------------------------------------
# FLHC runner
# ---------------------------------------------------------------------------

def run_flhc_concept_shift(
    nb_runs: int = 1,
    base_seed: int = 42,
    n_clusters: int = N_CLUSTERS,
    clients_per_cluster: int = CLIENTS_PER_CLUSTER,
):
    from cfla.framework.client.client_flhc import ClientFLHC
    from cfla.framework.server.server_flhc import ServerFLHC
    from cfla.framework.models.computer_vision import CNNCifar

    for run in range(nb_runs):
        seed = base_seed + run
        torch.manual_seed(seed)
        np.random.seed(seed)

        client_datasets, test_loader, num_classes = build_client_datasets_concept_shift(
            base_seed, run,
            n_clusters=n_clusters,
            clients_per_cluster=clients_per_cluster,
        )

        stamp = datetime.datetime.now().strftime("%y-%m-%d_%H-%M")
        output_dir = os.path.join("./RESULTS", f"result_flhc_concept_shift_{stamp}")

        client_args = {
            "local_epochs": 3,
            "device": DEVICE,
            "optimizer": torch.optim.SGD,
            "criterion": torch.nn.CrossEntropyLoss(reduction="mean"),
            "learning_rate": 0.01,
            "batch_size": 32,
            "train_fraction": 0.5,
            "monitor_energy": False,
            "output_dir": output_dir,
            "seed": seed,
        }

        clients = [
            ClientFLHC(client_id=cid, dataset=ds, output_dir=output_dir, args=client_args)
            for cid, ds in client_datasets.items()
            if len(ds) > 64
        ]

        server_args = {
            "fraction": 0.3,
            "device": DEVICE,
            "initial_rounds": 5,
            "cluster_rounds": 50,
            "distance_threshold": 0.5,
            "clustering_metric": "cosine",            "output_dir": output_dir,
            "seed": seed,
        }

        server = ServerFLHC(
            global_model=CNNCifar(num_classes=num_classes),
            args=server_args,
            test_dataloader=test_loader,
        )
        server.set_clients(clients=clients)
        server.train()


# ---------------------------------------------------------------------------
# HCFL runner
# ---------------------------------------------------------------------------

def run_hcfl_concept_shift(
    nb_runs: int = 1,
    base_seed: int = 42,
    n_clusters: int = N_CLUSTERS,
    clients_per_cluster: int = CLIENTS_PER_CLUSTER,
    mu: float = 1.0,
    lambda_0: float = 1.0,
    lambda_alpha: float = 0.1,
    lambda_p: float = 1.0,
):
    from cfla.framework.client.client_hcfl import ClientHCFL
    from cfla.framework.server.server_hcfl import ServerHCFL
    from cfla.framework.models.computer_vision import SplitCNNCifar

    for run in range(nb_runs):
        seed = base_seed + run
        torch.manual_seed(seed)
        np.random.seed(seed)

        client_datasets, test_loader, num_classes = build_client_datasets_concept_shift(
            base_seed, run,
            n_clusters=n_clusters,
            clients_per_cluster=clients_per_cluster,
        )

        stamp = datetime.datetime.now().strftime("%y-%m-%d_%H-%M")
        output_dir = os.path.join("./RESULTS", f"result_hcfl_concept_shift_{stamp}")
        os.makedirs(output_dir, exist_ok=True)

        client_args = {
            "local_epochs": 3,
            "local_steps": 0,
            "device": DEVICE,
            "optimizer": torch.optim.SGD,
            "criterion": torch.nn.CrossEntropyLoss(reduction="mean"),
            "learning_rate": 0.01,
            "batch_size": 32,
            "train_fraction": 0.5,
            "mu": mu,
            "monitor_energy": False,
            "output_dir": output_dir,
            "seed": seed,
        }

        clients = [
            ClientHCFL(client_id=cid, dataset=ds, output_dir=output_dir, args=client_args)
            for cid, ds in client_datasets.items()
            if len(ds) > 64
        ]

        server_args = {
            "fraction": 0.3,
            "device": DEVICE,
            "initial_rounds": 5,
            "cluster_rounds": 50,
            "distance_threshold": 0.5,
            "clustering_metric": "cosine",
            "lambda_0": lambda_0, "lambda_alpha": lambda_alpha, "lambda_p": lambda_p,
            "output_dir": output_dir,
            "seed": seed,
            "log_every": 10,
        }

        server = ServerHCFL(
            global_model=SplitCNNCifar(num_classes=num_classes),
            args=server_args,
            test_dataloader=test_loader,
        )
        server.set_clients(clients=clients)
        server.train(verbose=True)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    BASE_SEED = 2026

    print("=" * 60)
    print(f"Concept Shift — {N_CLUSTERS} clusters × {CLIENTS_PER_CLUSTER} clients")
    print(f"Label permutations: {_PERMUTATIONS}")
    print("=" * 60)

    print("\n>>> Running FLHC ...")
    run_flhc_concept_shift(nb_runs=1, base_seed=BASE_SEED)

    print("\n>>> Running HCFL ...")
    run_hcfl_concept_shift(nb_runs=1, base_seed=BASE_SEED,
                        lambda_0=1.0, lambda_alpha=0.1, lambda_p=1.0)
