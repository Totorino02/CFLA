"""
Covariate-shift partitioning for CFL benchmarking.

Unlike main.py (label-shift: each group has different classes), this module
creates a dataset where ALL groups share the SAME label distribution (all 10
classes) but have DIFFERENT feature distributions (covariate shift via per-group
image transforms).

Why this favours HCFL over FLHC:
- IID labels → head gradients are similar across clusters → full-model clustering
  (FLHC) loses discriminability.
- Feature shift → embedding gradients diverge across clusters → embedding-based
  clustering (HCFL) still works.
- HCFL's globally-shared embedding benefits from ALL clients' data → better
  representations despite fewer intra-cluster samples.

Three groups / three feature regimes:
  Group 0 – clean images  (original MNIST)
  Group 1 – noisy images  (additive Gaussian noise, std=0.3)
  Group 2 – inverted images (pixel inversion: 1 - x)
"""

import torch
DEVICE = "mps" if torch.backends.mps.is_available() else "cpu"
import numpy as np
from torch.utils.data import DataLoader, Dataset, Subset, random_split
from torchvision import datasets, transforms


# ---------------------------------------------------------------------------
# Per-group transforms
# ---------------------------------------------------------------------------

def _make_group_transforms():
    normalize = transforms.Normalize((0.1307,), (0.3081,))

    def add_noise(x: torch.Tensor) -> torch.Tensor:
        return torch.clamp(x + 0.3 * torch.randn_like(x), 0.0, 1.0)

    def invert(x: torch.Tensor) -> torch.Tensor:
        return 1.0 - x

    return [
        normalize,                                                          # group 0: clean
        transforms.Compose([transforms.Lambda(add_noise), normalize]),     # group 1: noisy
        transforms.Compose([transforms.Lambda(invert), normalize]),        # group 2: inverted
    ]


_GROUP_TRANSFORMS = _make_group_transforms()

# (class_range_start, class_range_end_inclusive, nb_clients)
# All groups span all 10 classes → IID label distribution
_GROUPS = [(0, 9, 18), (0, 9, 17), (0, 9, 15)]


# ---------------------------------------------------------------------------
# Dataset wrapper: applies a per-group transform on top of the base Subset
# ---------------------------------------------------------------------------

class _TransformDataset(Dataset):
    """Wraps a Subset and applies an additional transform to each sample."""

    def __init__(self, subset: Subset, extra_transform):
        self.subset = subset
        self.extra_transform = extra_transform

    def __len__(self):
        return len(self.subset)

    def __getitem__(self, idx):
        x, y = self.subset[idx]
        return self.extra_transform(x), y


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def build_client_datasets_covariate(
    base_seed: int,
    run: int,
    noise_ratio: float = 0.0,
):
    """
    Build client datasets under the covariate-shift regime.

    Returns (client_datasets, test_loader, num_classes) with the same
    interface as main.build_client_datasets so it is a drop-in replacement.

    Parameters
    ----------
    base_seed   : int   – reproducibility seed.
    run         : int   – run index (added to seed for multi-run experiments).
    noise_ratio : float – fraction of indices swapped between groups before
                          the per-group transform is applied.  At noise=0, the
                          feature clusters are perfectly clean.  Higher noise
                          mixes feature regimes, softening cluster boundaries.
    """
    # base transform: ToTensor only (per-group normalisation applied later)
    base_transform = transforms.ToTensor()
    train_ds = datasets.MNIST(root="./data", download=True, train=True,
                               transform=base_transform)
    test_ds  = datasets.MNIST(root="./data", download=True, train=False,
                               transform=transforms.Compose([
                                   transforms.ToTensor(),
                                   transforms.Normalize((0.1307,), (0.3081,)),
                               ]))

    targets = train_ds.targets  # tensor

    rng = np.random.default_rng(base_seed + run * 997)

    # Collect indices for each group (all classes → just split the full dataset)
    n_total = len(train_ds)
    all_indices = list(range(n_total))
    rng.shuffle(all_indices)

    n_groups = len(_GROUPS)
    chunk = n_total // n_groups
    group_indices = []
    for i in range(n_groups):
        start = i * chunk
        end = start + chunk if i < n_groups - 1 else n_total
        group_indices.append(all_indices[start:end])

    # Optional noise: swap noise_ratio of indices between groups
    if noise_ratio > 0.0:
        donated = [[] for _ in range(n_groups)]
        for i, indices in enumerate(group_indices):
            n_donate = int(len(indices) * noise_ratio)
            donate_pos = rng.choice(len(indices), size=n_donate, replace=False)
            donated_samples = [indices[j] for j in donate_pos]
            keep = [idx for k, idx in enumerate(indices)
                    if k not in set(donate_pos)]
            group_indices[i] = keep
            other_groups = [g for g in range(n_groups) if g != i]
            chunk_size = max(1, n_donate // len(other_groups))
            for k, g in enumerate(other_groups):
                s = k * chunk_size
                e = s + chunk_size if k < len(other_groups) - 1 else n_donate
                donated[g].extend(donated_samples[s:e])
        for i in range(n_groups):
            group_indices[i].extend(donated[i])
            rng.shuffle(group_indices[i])

    # Build per-client datasets
    client_datasets = {}
    cid = 0
    for i, ((lo, hi, n_clients), indices) in enumerate(zip(_GROUPS, group_indices)):
        subset = Subset(train_ds, indices)
        # split into n_clients partitions
        length = len(subset)
        base_size = length // n_clients
        sizes = [base_size] * n_clients
        for j in range(length - base_size * n_clients):
            sizes[j] += 1
        partitions = random_split(
            subset, sizes,
            generator=torch.Generator().manual_seed(base_seed + run * (i + 2)),
        )
        group_tf = _GROUP_TRANSFORMS[i]
        for p in partitions:
            client_datasets[cid] = _TransformDataset(p, group_tf)
            cid += 1

    test_loader = DataLoader(test_ds, batch_size=64, shuffle=False)
    return client_datasets, test_loader, 10


# ---------------------------------------------------------------------------
# Experiment runners (thin wrappers that swap in the new dataset builder)
# ---------------------------------------------------------------------------

def run_flhc_covariate(nb_runs=1, base_seed=42, noise_ratio=0.0):
    import datetime, os
    from cfla.framework.client.client_flhc import ClientFLHC
    from cfla.framework.server.server_flhc import ServerFLHC
    from cfla.framework.models.computer_vision import LeNet5V1

    for run in range(nb_runs):
        seed = base_seed + run
        torch.manual_seed(seed)
        np.random.seed(seed)

        client_datasets, test_loader, num_classes = build_client_datasets_covariate(
            base_seed, run, noise_ratio=noise_ratio
        )

        stamp = datetime.datetime.now().strftime("%y-%m-%d_%H-%M")
        output_dir = os.path.join("./RESULTS", f"result_flhc_covariate_{stamp}")

        client_args = {
            "local_epochs": 3,
            "device": DEVICE,
            "optimizer": torch.optim.SGD,
            "criterion": torch.nn.CrossEntropyLoss(reduction="mean"),
            "learning_rate": 0.01,
            "batch_size": 32,
            "train_fraction": 0.2,
            "monitor_energy": False,
            "output_dir": output_dir,
            "seed": seed,
        }

        clients = [
            ClientFLHC(client_id=cid, dataset=ds, output_dir=output_dir, args=client_args)
            for cid, ds in client_datasets.items()
            if len(ds) > 64
        ]

        server_args = {
            "fraction": 0.2,
            "device": DEVICE,
            "initial_rounds": 3,
            "cluster_rounds": 50,
            "distance_threshold": 0.5,
            "clustering_metric": "cosine",
            "n_clusters": None,
            "output_dir": output_dir,
            "seed": seed,
        }

        server = ServerFLHC(
            global_model=LeNet5V1(),
            args=server_args,
            test_dataloader=test_loader,
        )
        server.set_clients(clients=clients)
        server.train()


def run_hcfl_covariate(nb_runs=1, base_seed=42, noise_ratio=0.0,
                       mu=1.0, lambda_0=1.0, lambda_alpha=0.1, lambda_p=1.0):
    import datetime, os
    from cfla.framework.client.client_hcfl import ClientHCFL
    from cfla.framework.server.server_hcfl import ServerHCFL
    from cfla.framework.models.computer_vision import SplitLeNet5V1

    for run in range(nb_runs):
        seed = base_seed + run
        torch.manual_seed(seed)
        np.random.seed(seed)

        client_datasets, test_loader, num_classes = build_client_datasets_covariate(
            base_seed, run, noise_ratio=noise_ratio
        )

        stamp = datetime.datetime.now().strftime("%y-%m-%d_%H-%M")
        output_dir = os.path.join("./RESULTS", f"result_hcfl_covariate_{stamp}")
        os.makedirs(output_dir, exist_ok=True)

        client_args = {
            "local_epochs": 3,
            "local_steps": 0,
            "device": DEVICE,
            "optimizer": torch.optim.SGD,
            "criterion": torch.nn.CrossEntropyLoss(reduction="mean"),
            "learning_rate": 0.01,
            "batch_size": 32,
            "train_fraction": 0.2,
            "mu": mu,
            "monitor_energy": False,
            "output_dir": output_dir,
            "seed": seed,
        }

        clients = [
            ClientHCFL(client_id=cid, dataset=ds, output_dir=output_dir, args=client_args)
            for cid, ds in client_datasets.items()
            if len(ds) > 64
        ]

        server_args = {
            "fraction": 0.2,
            "device": DEVICE,
            "initial_rounds": 3,
            "cluster_rounds": 50,
            "distance_threshold": 0.5,
            "clustering_metric": "cosine",
            "n_clusters": None,
            "lambda_0": lambda_0, "lambda_alpha": lambda_alpha, "lambda_p": lambda_p,
            "output_dir": output_dir,
            "seed": seed,
            "log_every": 10,
        }

        server = ServerHCFL(
            global_model=SplitLeNet5V1(),
            args=server_args,
            test_dataloader=test_loader,
        )
        server.set_clients(clients=clients)
        server.train(verbose=True)


if __name__ == "__main__":
    base_seed = 2026
    noise_ratio = 0.0  # start clean; increase to soften cluster boundaries

    run_flhc_covariate(nb_runs=1, base_seed=base_seed, noise_ratio=noise_ratio)
    run_hcfl_covariate(nb_runs=1, base_seed=base_seed, noise_ratio=noise_ratio)
