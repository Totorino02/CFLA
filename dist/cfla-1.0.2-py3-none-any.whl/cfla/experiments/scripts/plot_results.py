"""
Plot performance curves and comparison table for CFL experiments.

Usage:
    python -m experiments.scripts.plot_results
    python -m experiments.scripts.plot_results --results_dir ./RESULTS --output_dir ./PLOTS
"""

import argparse
import glob
import os

import matplotlib
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import numpy as np
import pandas as pd

matplotlib.rcParams.update(
    {
        "font.family": "DejaVu Sans",
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.grid": True,
        "grid.alpha": 0.35,
        "grid.linestyle": "--",
        "figure.dpi": 150,
    }
)

# ──────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────

ALGO_LABELS = {
    "flhc": "FLHC (Briggs et al.)",
    "hcfl": "HCFL (ours)",
    "lcfed": "LCFed (Zhang et al.)",
    "fedper": "FedPer (Li et al.)",
    "fedgroup": "FedGroup (Wang et al.)",
    "fesem": "FeSEM (Chen et al.)",
    "cgpfl": "CGPFL (Liu et al.)",
    "ifca": "IFCA (Zhang et al.)",
}

ALGO_COLORS = {
    "flhc": "#e15759",
    "hcfl": "#4e79a7",
    "lcfed": "#f28e2b",
    "fedper": "#76b7b2",
    "fedgroup": "#59a14f",
    "fesem": "#edc949",
    "cgpfl": "#af7aa1",
    "ifca": "#ff9da7",
    "embed-Share": "#ed7028",
    "embed-noShare": "#37d61b",
    "full-Share": "#135de5",
    "full-noShare": "#ec1317",
}

ALGO_MARKERS = {
    "flhc": "o",
    "hcfl": "s",
    "lcfed": "^",
    "fedper": "D",
    "fedgroup": "v",
    "fesem": "<",
    "cgpfl": ">",
    "ifca": "p",
}


def _discover_runs(results_dir: str) -> dict[str, dict[str, list[str]]]:
    """
    Returns {dataset: {algo: [path1, path2, ...]}} for all result folders found.
    Folder naming convention: result_{algo}_{dataset}_{stamp}
    """
    runs: dict[str, dict[str, list[str]]] = {}
    for folder in sorted(glob.glob(os.path.join(results_dir, "result_*"))):
        parts = os.path.basename(folder).split("_")
        if len(parts) < 3:
            continue
        algo = parts[1]
        dataset = parts[2]
        runs.setdefault(dataset, {}).setdefault(algo, []).append(folder)
    return runs


def _load_server_metrics(paths: list[str]) -> pd.DataFrame:
    """
    Average server_metrics.csv across multiple runs (if any).
    Returns DataFrame with columns [round, mean_acc, std_acc, mean_loss].
    """
    frames = []
    for p in paths:
        csv_path = os.path.join(p, "server_metrics.csv")
        if os.path.exists(csv_path):
            frames.append(pd.read_csv(csv_path))
    if not frames:
        return pd.DataFrame()
    combined = pd.concat(frames)
    return combined.groupby("round", as_index=False).mean()


def _load_all_client_accs(paths: list[str]) -> pd.DataFrame:
    """
    Load accuracy_after for every client across all runs.
    Returns DataFrame with columns [round, accuracy_after, client_id, run].
    """
    rows = []
    for run_idx, p in enumerate(paths):
        for client_dir in glob.glob(os.path.join(p, "client_*")):
            cid = os.path.basename(client_dir).replace("client_", "")
            csv_path = os.path.join(client_dir, "metrics.csv")
            if not os.path.exists(csv_path):
                continue
            df = pd.read_csv(csv_path, skipinitialspace=True)
            # keep only non-negative rounds (skip pre-learning rows with round < 0)
            df = df[df["round"] >= 0].copy()
            df["client_id"] = int(cid)
            df["run"] = run_idx
            rows.append(df[["round", "accuracy_after", "client_id", "run"]])
    if not rows:
        return pd.DataFrame()
    return pd.concat(rows, ignore_index=True)


# ──────────────────────────────────────────────
# Plots
# ──────────────────────────────────────────────


def plot_accuracy_curves(data: dict[str, pd.DataFrame], output_dir: str, dataset: str):
    fig, ax = plt.subplots(figsize=(8, 5))

    for algo, df in data.items():
        if df.empty:
            continue
        rounds = df["round"].values
        acc = df["mean_acc"].values
        std = df["std_acc"].values
        color = ALGO_COLORS.get(algo, "#333333")
        marker = ALGO_MARKERS.get(algo, "o")

        ax.plot(
            rounds,
            acc,
            color=color,
            marker=marker,
            markevery=max(1, len(rounds) // 10),
            markersize=5,
            linewidth=1.8,
            label=ALGO_LABELS.get(algo, algo),
        )
        ax.fill_between(rounds, acc - std, acc + std, alpha=0.15, color=color)

    ax.yaxis.set_major_formatter(mticker.PercentFormatter(xmax=1, decimals=0))
    ax.set_xlabel("Round")
    ax.set_ylabel("Mean accuracy (all clients)")
    ax.set_title(f"Accuracy over rounds — {dataset.upper()}")
    ax.legend(framealpha=0.9)
    fig.tight_layout()
    path = os.path.join(output_dir, f"accuracy_curves_{dataset}.png")
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)
    print(f"Saved: {path}")


def plot_loss_curves(data: dict[str, pd.DataFrame], output_dir: str, dataset: str):
    fig, ax = plt.subplots(figsize=(8, 5))

    for algo, df in data.items():
        if df.empty:
            continue
        rounds = df["round"].values
        loss = df["mean_loss"].values
        color = ALGO_COLORS.get(algo, "#333333")
        marker = ALGO_MARKERS.get(algo, "o")

        ax.plot(
            rounds,
            loss,
            color=color,
            marker=marker,
            markevery=max(1, len(rounds) // 10),
            markersize=5,
            linewidth=1.8,
            label=ALGO_LABELS.get(algo, algo),
        )

    ax.set_xlabel("Round")
    ax.set_ylabel("Mean loss (all clients)")
    ax.set_title(f"Loss over rounds — {dataset.upper()}")
    ax.legend(framealpha=0.9)
    fig.tight_layout()
    path = os.path.join(output_dir, f"loss_curves_{dataset}.png")
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)
    print(f"Saved: {path}")


def plot_accuracy_boxplot(client_data: dict[str, pd.DataFrame], output_dir: str, dataset: str):
    """
    Final-round accuracy distribution across clients (box plot).
    """
    fig, ax = plt.subplots(figsize=(7, 5))

    box_data = []
    labels = []
    colors = []
    for algo, df in client_data.items():
        if df.empty:
            continue
        last_round = df["round"].max()
        final = df[df["round"] == last_round]["accuracy_after"].values
        box_data.append(final)
        labels.append(ALGO_LABELS.get(algo, algo))
        colors.append(ALGO_COLORS.get(algo, "#333333"))

    bp = ax.boxplot(
        box_data, patch_artist=True, widths=0.45, medianprops=dict(color="black", linewidth=2)
    )
    for patch, color in zip(bp["boxes"], colors):
        patch.set_facecolor(color)
        patch.set_alpha(0.7)

    ax.set_xticklabels(labels, rotation=90)
    ax.yaxis.set_major_formatter(mticker.PercentFormatter(xmax=1, decimals=0))
    ax.set_ylabel("Accuracy (last round)")
    ax.set_title(f"Per-client accuracy distribution — {dataset.upper()} — final round")
    fig.tight_layout()
    path = os.path.join(output_dir, f"accuracy_boxplot_{dataset}.png")
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)
    print(f"Saved: {path}")


def plot_convergence_speed(
    data: dict[str, pd.DataFrame], output_dir: str, dataset: str, target: float = 0.80
):
    """
    Bar chart: number of rounds to reach `target` accuracy.
    """
    fig, ax = plt.subplots(figsize=(6, 4))
    algos, rounds_to_target, colors = [], [], []

    for algo, df in data.items():
        if df.empty:
            continue
        reached = df[df["mean_acc"] >= target]
        r = int(reached["round"].iloc[0]) if not reached.empty else None
        algos.append(ALGO_LABELS.get(algo, algo))
        rounds_to_target.append(r if r is not None else len(df))
        colors.append(ALGO_COLORS.get(algo, "#333333"))

    bars = ax.bar(algos, rounds_to_target, color=colors, alpha=0.85, width=0.5)
    for bar, v in zip(bars, rounds_to_target):
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height() + 0.5,
            str(v),
            ha="center",
            va="bottom",
            fontsize=10,
        )

    ax.set_ylabel("Rounds")
    ax.set_title(f"Rounds to reach {target:.0%} mean accuracy — {dataset.upper()}")
    ax.set_xticks(range(len(algos)))
    ax.set_xticklabels(algos, rotation=90)
    fig.tight_layout()
    path = os.path.join(output_dir, f"convergence_speed_{dataset}.png")
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)
    print(f"Saved: {path}")


# ──────────────────────────────────────────────
# Comparison table
# ──────────────────────────────────────────────


def build_comparison_table(
    server_data: dict[str, pd.DataFrame],
    client_data: dict[str, pd.DataFrame],
    output_dir: str,
    dataset: str,
    target: float = 0.80,
) -> pd.DataFrame:
    rows = []
    for algo in server_data:
        df_s = server_data[algo]
        df_c = client_data.get(algo, pd.DataFrame())
        if df_s.empty:
            continue

        last_round = df_s["round"].max()
        final_row = df_s[df_s["round"] == last_round].iloc[0]

        # Final round metrics
        final_mean_acc = final_row["mean_acc"]
        final_std_acc = final_row["std_acc"]
        final_mean_loss = final_row["mean_loss"]

        # Best accuracy across all rounds
        best_acc = df_s["mean_acc"].max()

        # Convergence speed
        reached = df_s[df_s["mean_acc"] >= target]
        rounds_to_target = (
            int(reached["round"].iloc[0]) if not reached.empty else f">{int(last_round)}"
        )

        # Per-client stats at last round
        if not df_c.empty:
            final_clients = df_c[df_c["round"] == df_c["round"].max()]["accuracy_after"]
            min_acc = final_clients.min()
            max_acc = final_clients.max()
            p10_acc = np.percentile(final_clients, 10)
            p90_acc = np.percentile(final_clients, 90)
        else:
            min_acc = max_acc = p10_acc = p90_acc = float("nan")

        rows.append(
            {
                "Algorithm": ALGO_LABELS.get(algo, algo),
                "Final mean acc": f"{final_mean_acc:.3f}",
                "Final std acc": f"{final_std_acc:.3f}",
                "Best mean acc": f"{best_acc:.3f}",
                "Final mean loss": f"{final_mean_loss:.4f}",
                f"Rounds to {target:.0%}": rounds_to_target,
                "Min client acc": f"{min_acc:.3f}",
                "P10 client acc": f"{p10_acc:.3f}",
                "P90 client acc": f"{p90_acc:.3f}",
                "Max client acc": f"{max_acc:.3f}",
            }
        )

    table = pd.DataFrame(rows)
    csv_path = os.path.join(output_dir, f"comparison_table_{dataset}.csv")
    table.to_csv(csv_path, index=False)
    print(f"Saved: {csv_path}")

    # Pretty-print
    print("\n" + "=" * 90)
    print(f"COMPARISON TABLE — {dataset.upper()}")
    print("=" * 90)
    print(table.to_string(index=False))
    print("=" * 90 + "\n")

    return table


# ──────────────────────────────────────────────
# Main
# ──────────────────────────────────────────────


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--results_dir", default="./RESULTS")
    parser.add_argument("--output_dir", default="./PLOTS")
    parser.add_argument(
        "--target_acc",
        type=float,
        default=0.80,
        help="Accuracy threshold for convergence-speed chart",
    )
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)

    all_runs = _discover_runs(args.results_dir)
    if not all_runs:
        print(f"No result folders found in {args.results_dir}")
        return

    print(f"Found datasets: {list(all_runs.keys())}")

    for dataset, runs in sorted(all_runs.items()):
        print(f"\n── {dataset.upper()} ──")
        print(f"  Algos: {list(runs.keys())}")

        dataset_dir = os.path.join(args.output_dir, dataset)
        os.makedirs(dataset_dir, exist_ok=True)

        server_data = {algo: _load_server_metrics(paths) for algo, paths in runs.items()}
        client_data = {algo: _load_all_client_accs(paths) for algo, paths in runs.items()}

        plot_accuracy_curves(server_data, dataset_dir, dataset)
        plot_loss_curves(server_data, dataset_dir, dataset)
        plot_accuracy_boxplot(client_data, dataset_dir, dataset)
        plot_convergence_speed(server_data, dataset_dir, dataset, target=args.target_acc)
        build_comparison_table(
            server_data, client_data, dataset_dir, dataset, target=args.target_acc
        )


if __name__ == "__main__":
    main()
